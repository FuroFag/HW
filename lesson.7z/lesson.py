name = 'this is so sad that Steve Jobs died of Ligma'
print(name [0])
print(name [-1])
print(name [22:44])
print(name [::-1])
print(name [1::2])