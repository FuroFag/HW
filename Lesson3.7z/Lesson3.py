name = 'Егор'
print ('Имя:', name)
age = 21
print ('Возраст:', age)
print ('Новый возраст:' ,age + 1)
IsStudent = True
print ('Студент:', IsStudent)