AmountOfCompletedHomework = (12)
TimeSpent = (1.5)
CourseName = 'Python'
TimeOnOneTask = ((TimeSpent) / (AmountOfCompletedHomework))
print (CourseName, 'всего задач', AmountOfCompletedHomework, ', затрачено часов', TimeSpent, ', среднее время выполнения', TimeOnOneTask)