my_string = 'заходят как-то коммунист, фашист и еврей в бар, а бармен им и говорит: "Владимир Вольфивич, добрый вечер"'
type (my_string)
n = len (my_string)
print ('строка состоит из', n, 'сиволов')
print (my_string .upper())
print (my_string .lower())
print (my_string .replace(" ", ""))
print (my_string [0])
print (my_string [-1])

