#Immutable_var = (1, 2, 'abc')
#print (Immutable_var)
#Immutable_var [0] = 11 # Невозможно изменить элемент кортежа так, как это неизменяемый тип данных
#print (Immutable_var)

mutable_list = [1, 2, 3, 4, 5]
mutable_list [0] = 'abc'
print (mutable_list)